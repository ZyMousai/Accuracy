module.exports = {
  messages: {
    CN: {
      content: '演示页面',
      description: '这是一个演示页面'
    },
    HK: {
      content: '演示頁面',
      description: '這是一個演示頁面'
    },
    US: {
      content: 'Demo Page',
      description: 'This is a demo page'
    }
  }
}