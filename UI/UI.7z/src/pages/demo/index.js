import Demo from './Demo.vue'
export default Demo