import voluumsiteId from './index.vue'
export default voluumsiteId