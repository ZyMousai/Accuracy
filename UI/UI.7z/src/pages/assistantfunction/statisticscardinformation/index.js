import accountmanagement from './index.vue'
export default accountmanagement