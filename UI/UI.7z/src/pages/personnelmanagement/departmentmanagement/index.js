import departmentmanagement from './index.vue'
export default departmentmanagement