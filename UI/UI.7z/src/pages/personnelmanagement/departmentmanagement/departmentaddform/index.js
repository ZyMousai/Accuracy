import AdvancedForm from '@/pages/personnelmanagement/departmentmanagement/departmentaddform/AdvancedForm'
export default AdvancedForm