import personaldata from './index.vue'
export default personaldata