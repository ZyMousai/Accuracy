import dashboard from './index.vue'
export default dashboard