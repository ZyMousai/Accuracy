import recyclebin from './index.vue'
export default recyclebin