import document from './index.vue'
export default document